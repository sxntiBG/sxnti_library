def Sumar(a, b):
    return a + b

def Restar(a, b):
    return a - b